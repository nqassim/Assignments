touch demand_data.txt
echo "Store new data in here">>demand_data.txt
export HISTTIMEFORMAT="%d/%m/%y %T "
touch demands.log
history 1 >>  demands.log
